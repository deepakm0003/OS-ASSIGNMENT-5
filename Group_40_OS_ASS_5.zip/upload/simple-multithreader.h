#ifndef SIMPLE_THREADER_H
#define SIMPLE_THREADER_H

#include <iostream>
#include <functional>
#include <pthread.h>
#include <chrono>
#include <vector>
#include <cstring>
#include <cstdlib>

int user_main(int argc, char **argv);

struct ThreadArgs {
    int thread_id;
    int start;
    int end;
    std::function<void(int)>* lambda;
    
    ThreadArgs(int id, int s, int e, std::function<void(int)>* l) 
        : thread_id(id), start(s), end(e), lambda(l) {}
};

struct ThreadArgs2D {
    int thread_id;
    int start1;
    int end1;
    int start2;
    int end2;
    std::function<void(int, int)>* lambda;
    
    ThreadArgs2D(int id, int s1, int e1, int s2, int e2, std::function<void(int, int)>* l)
        : thread_id(id), start1(s1), end1(e1), start2(s2), end2(e2), lambda(l) {}
};

void* thread_func_1D(void* args) {
    ThreadArgs* tArgs = static_cast<ThreadArgs*>(args);
    for (int i = tArgs->start; i < tArgs->end; ++i) {
        (*(tArgs->lambda))(i);
    }
    return nullptr;
}

void* thread_func_2D(void* args) {
    ThreadArgs2D* tArgs = static_cast<ThreadArgs2D*>(args);
    for (int i = tArgs->start1; i < tArgs->end1; ++i) {
        for (int j = tArgs->start2; j < tArgs->end2; ++j) {
            (*(tArgs->lambda))(i, j);
        }
    }
    return nullptr;
}

template<typename T>
std::vector<T> calculate_chunks(int start, int end, int num_threads) {
    std::vector<T> chunks;
    int range = end - start;
    int base_chunk = range / num_threads;
    int remainder = range % num_threads;
    
    int current = start;
    for (int i = 0; i < num_threads; ++i) {
        int chunk_size = base_chunk + (i < remainder ? 1 : 0);
        int next = current + chunk_size;
        chunks.push_back(T(i, current, next, nullptr));
        current = next;
    }
    return chunks;
}

void parallel_for(int low, int high, std::function<void(int)> &&lambda, int numThreads) {
    auto start_time = std::chrono::high_resolution_clock::now();

    // Create thread containers
    std::vector<pthread_t> threads(numThreads);
    auto chunks = calculate_chunks<ThreadArgs>(low, high, numThreads);
    
    for (auto& chunk : chunks) {
        chunk.lambda = &lambda;
    }
    
    // Create threads
    for (int i = 0; i < numThreads; ++i) {
        pthread_create(&threads[i], nullptr, thread_func_1D, &chunks[i]);
    }
    
    // Join threads and print ranges
    for (int i = 0; i < numThreads; ++i) {
        pthread_join(threads[i], nullptr);
        std::cout << "Thread " << threads[i] << ": Processing range " 
                  << chunks[i].start << " to " << chunks[i].end - 1 << "\n";
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
    std::cout << "1D Parallel_for Execution Time: " << duration.count() << " ms\n";
}

void parallel_for(int low1, int high1, int low2, int high2, 
                 std::function<void(int, int)> &&lambda, int numThreads) {
    auto start_time = std::chrono::high_resolution_clock::now();

    std::vector<pthread_t> threads(numThreads);
    std::vector<ThreadArgs2D> chunks;
    
   int range1 = high1 - low1;
    int base_chunk = range1 / numThreads;
    int remainder = range1 % numThreads;
    
    // Create chunks
    int current = low1;
    for (int i = 0; i < numThreads; ++i) {
        int chunk_size = base_chunk + (i < remainder ? 1 : 0);
        int next = current + chunk_size;
        chunks.emplace_back(i, current, next, low2, high2, &lambda);
        current = next;
    }
    
    // Create threads
    for (int i = 0; i < numThreads; ++i) {
        pthread_create(&threads[i], nullptr, thread_func_2D, &chunks[i]);
    }
    
    for (int i = 0; i < numThreads; ++i) {
        pthread_join(threads[i], nullptr);
        std::cout << "Thread " << threads[i] << ": Processing rows " 
                  << chunks[i].start1 << " to " << chunks[i].end1 - 1 << "\n";
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
    std::cout << "2D Parallel_for Execution Time: " << duration.count() << " ms\n";
}

void demonstration(std::function<void()> &&lambda) {
    lambda();
}

// Main function wrapper
int main(int argc, char **argv) {
    int x = 5, y = 1;
    demonstration([x, &y]() {
        y = 5;
        std::cout << "====== Welcome to Assignment-" << y << " of the CSE231(A) ======\n";
    });

    int rc = user_main(argc, argv);

    demonstration([]() {
        std::cout << "====== Hope you enjoyed CSE231(A) ======\n";
    });

    return rc;
}

#define main user_main

#endif // SIMPLE_THREADER_H